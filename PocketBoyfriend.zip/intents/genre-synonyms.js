module.exports = [
  {
    genre: "science fiction",
    synonyms: ["sci fi", "scientific", "science"]
  } ,
  {
    genre: "Romance",
    synonyms: ["romantic"]
  },
  {
    genre: "Romantic",
    synonyms: ["romance"]
  },
  {
    genre: "Comedy",
    synoynms: ["funny", "comedic", "happy"]
  },
  {
    genre: "Mystery",
    synonyms: ["detective", "mysterious"]
  }
]
