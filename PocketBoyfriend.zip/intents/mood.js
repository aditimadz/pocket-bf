module.exports =  [
  {
    mood: "happy",
    genre: ["animation", "romance", "comedy", "documentary", "dramas", "action", "adventure"]
  },
  {
    mood: "seebs",
    genre: ["animation", "western", "crime"]
  },
  {
    mood: "tired",
    genre: ["animation", "family", "history"]
  },
  {
    mood: "cheerful",
    genre: ["animation", "adventure", "comedy", "action", "fantasy"]
  },
  {
    mood: "angry",
    genre: ["mystery", "science fiction", "documentary"]
  },
  {
    mood: "ceebs",
    genre: []
  },
  {
    mood: "excited",
    genre: ["animation", "adventure", "comedy", "action", "fantasy"]
  },
  {
    mood: "sad",
    genre: ["family", "drama", "fantasy", "history"]
  },
  {
    mood: "annoyed",
    genre: ["action", "drama"]
  },
  {
    mood: "joyful",
    genre: ["comedy", "romance"]
  }
]
