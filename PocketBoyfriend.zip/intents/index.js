const MovieDbSdk = require('../libs/movies');
const LexIntents = require('../libs/lex');
const GenreByMood = require('./mood');
const _find = require('lodash/fp/find');
const _sample = require('lodash/sample');

function suggestGenreByMood(mood) {
  const { genre } = _find({ mood }, GenreByMood);
  return _sample(genre);
}

module.exports = {
  GetMovieRecommendation: {
    async handler({ intentRequest, callback }) {
      const { sessionAttributes, currentIntent: { slots, confirmationStatus } } = intentRequest;
      const movie = await MovieDbSdk.getMovieRecommendationsWithFilter(slots);

      // Denied genre suggestion from mood
      if (confirmationStatus === 'Denied') {
        const { mood } = sessionAttributes;
        const newSuggestedGenre = suggestGenreByMood(mood)
        // Resuggest
        return callback(LexIntents.confirm({
          sessionAttributes: {
            genre: newSuggestedGenre,
            mood
          },
          slots: {
            genre: newSuggestedGenre,
            celebrity: null
          },
          intentProperties: { intentName: 'GetMovieRecommendation' },
          message: {
            contentType: 'PlainText',
            content: `Okay, how about watching a ${newSuggestedGenre} movie?`
          }
        }))
      }

      return callback(LexIntents.confirm({
        sessionAttributes: {
          movieOverview: movie.overview,
          ...slots
        },
        slots: {
            movieName: movie.title
        },
        intentProperties: {
            intentName: 'GetMovieInformation'   // Next intent to invoke
        },
        message: {
            contentType: 'PlainText',
            content: `What about ${movie.title}. Want me to tell your more about the movie?`
        }
      }));
    },
    async hook({ intentRequest,  callback }) {
      const { currentIntent: { slots } } = intentRequest;
      // validate hooks

    }
  },
  GetMovieInformation: {
    async handler({ intentRequest, callback }) {
      const { sessionAttributes, currentIntent: { slots, confirmationStatus } } = intentRequest;
      if (confirmationStatus === 'Denied' || confirmationStatus === 'None') {
        const { genre, celebrity } = sessionAttributes;
        const movie = await MovieDbSdk.getMovieRecommendationsWithFilter({ genre, celebrity });
        callback(LexIntents.confirm({
          sessionAttributes: {
            genre,
            celebrity,
            movieOverview: movie.overview
          },
          slots: {
            movieName: movie.title,
          },
          intentProperties: {
              intentName: 'GetMovieInformation'   // Next intent to invoke
          },
          message: {
              contentType: 'PlainText',
              content: `How about ${movie.title}. Want to hear a summary of the movie?`
          }
        }));
      }
      return callback(LexIntents.close({ sessionAttributes, fulfillmentState: 'Fulfilled', message: {
        contentType: 'PlainText',
        content: `Here is an overview I found: ${sessionAttributes.movieOverview}`
      }}));
    }
  },
  GetMovieByMood: {
    async handler({ intentRequest, callback }) {
      const { sessionAttributes, currentIntent: { slots, confirmationStatus } } = intentRequest;
      let { mood } = slots;
      const { genre } = _find({ mood }, GenreByMood);
      const suggestedGenre = _sample(genre)
      let content;
      if (['sad', 'bad', 'unhappy', 'annoyed'].includes(mood)) {
        mood = 'sad';
        content = `Aww. Let's watch a movie to take your mind off things. How about a movie in the ${suggestedGenre} genre. Up for it?`;
      } else if(mood === 'happy'){
        content = `That's good to hear. Lets chill and watch a movie. I would suggests a movie in the ${suggestedGenre} genre. Up for it?`;
      } else {
        content = `Let's watch a movie and chill. I'd suggest a movie in the ${suggestedGenre} genre. What do you think?`
      }
      callback(LexIntents.confirm({
        sessionAttributes: {
          genre: suggestedGenre,
          mood
        },
        slots: {
          genre: suggestedGenre,
          celebrity: null
        },
        intentProperties: { intentName: 'GetMovieRecommendation' },
        message: {
          contentType: 'PlainText',
          content
        }
      }))
    }
  }
}
